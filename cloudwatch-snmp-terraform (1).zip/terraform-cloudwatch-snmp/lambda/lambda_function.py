import os
import json
from pysnmp.hlapi import *

def lambda_handler(event, context):
    snmp_target = os.environ['SNMP_TARGET']
    snmp_port = int(os.environ.get('SNMP_PORT', 162))

    message = json.dumps(event)

    errorIndication, _, _, _ = next(
        sendNotification(
            SnmpEngine(),
            CommunityData('public', mpModel=1),
            UdpTransportTarget((snmp_target, snmp_port)),
            ContextData(),
            'trap',
            NotificationType(
                ObjectIdentity('1.3.6.1.4.1.8072.2.3.0.1')  # example OID
            ).addVarBinds(
                ('1.3.6.1.2.1.1.1.0', OctetString(message[:255]))  # truncate if needed
            )
        )
    )

    if errorIndication:
        print(f"SNMP error: {errorIndication}")
    return {'statusCode': 200, 'body': 'SNMP Trap sent'}